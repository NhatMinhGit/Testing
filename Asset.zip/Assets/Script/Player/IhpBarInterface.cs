﻿internal interface IhpBarInterface
{
    int HP();
}